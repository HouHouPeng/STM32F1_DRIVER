#ifndef BEEP__H_
#define BEEP__H_

#include "sys.h"
void beep_init(void);

#endif